let bindings_path = "_includes/bindings.bc"
let stdlib_path = "_includes/stdlib.dice"